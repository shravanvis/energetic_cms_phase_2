import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddUpdateSubsubcategoryComponent } from 'app/modals/add-update-subsubcategory/add-update-subsubcategory.component';
import { ApiService } from 'app/service/api.service';
import { UtilService } from 'app/service/util.service';

@Component({
  selector: 'app-subsubcategory',
  templateUrl: './subsubcategory.component.html',
  styleUrls: ['./subsubcategory.component.css']
})
export class SubsubcategoryComponent implements OnInit {

  subsub_id;
  sub_id;

  category_id;

  image1_src: any;
  image2_src: any;
  image3_src: any;

  subsubname: any;
  description: any;

  image1: string = '';
  image2: string = '';
  image3: string = '';

  public files: any[];
  public files2: any[];
  public files3: any[];

  updateview: boolean = false;
  Addview: boolean = true;
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private utilService: UtilService,
    public apiService: ApiService,
    private modalService: NgbModal,
    private http: HttpClient
  ) {
    this.activatedRoute.params.subscribe(params => {
      // alert(this.id);
    })
  }

  ngOnInit(): void {
    this.category_id = localStorage.getItem('category_id');
    this.sub_id = localStorage.getItem('sub_id');
    this.getAllSubSubCategory(this.sub_id);

  }

  getAllSubSubCategory(id) {
    this.apiService.getAPI(this.apiService.BASE_URL + 'subSubCategory/getSubSubCategory/' + id).then((result) => {
      console.log(result);
      if (result.status) {
        this.updateview = true;
        this.Addview = false;
        this.subsubname = result.result.subsubname;
        this.description = result.result.description;
        this.subsub_id = result.result.id;
        this.sub_id = result.result.subcat_id;
        this.category_id = result.result.category_id;
        this.image1_src = this.apiService.BASE_IMAGE_URL + result.result.image;
        this.image2_src = this.apiService.BASE_IMAGE_URL + result.result.image2;
        this.image3_src = this.apiService.BASE_IMAGE_URL + result.result.image3;
      }
      else {
        this.updateview = false;
        this.Addview = true;
      }
    })
  }

  onimage1(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.image1 = file

      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.image1_src = reader.result;
      }
    }
  }

  onimage2(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.image2 = file

      var reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (_event) => {
        this.image2_src = reader.result;
      }
    }
  }

  onimage3(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.image3 = file

      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.image3_src = reader.result;
      }
    }
  }

  Update() {
    const formData = new FormData();
    formData.append('id', this.subsub_id);
    formData.append('category_id', this.category_id);
    formData.append('subcat_id', this.sub_id);
    formData.append('subsubname', this.subsubname);
    formData.append('description', this.description);
    formData.append('image', this.image1);
    formData.append('image2', this.image2);
    formData.append('image3', this.image3);

    this.apiService.postAPI(this.apiService.BASE_URL + 'subSubCategory/updateSubSubCategory', formData).then((result) => {
      alert(result.message);
    })
  }

  Add() {
    const formData = new FormData();
    formData.append('category_id', this.category_id);
    formData.append('subcat_id', this.sub_id);
    formData.append('subsubname', this.subsubname);
    formData.append('description', this.description);
    formData.append('image', this.image1);
    formData.append('image2', this.image2);
    formData.append('image3', this.image3);

    this.apiService.postAPI(this.apiService.BASE_URL + 'subSubCategory/addSubSubCategory', formData).then((result) => {
      alert(result.message);
    })
  }
}
