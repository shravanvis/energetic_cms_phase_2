import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateOemContactComponent } from './add-update-oem-contact.component';

describe('AddUpdateOemContactComponent', () => {
  let component: AddUpdateOemContactComponent;
  let fixture: ComponentFixture<AddUpdateOemContactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUpdateOemContactComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUpdateOemContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
